def sub2(numbers):
    """
    Given an list of integers of the size of N,
    you need to return (start_index, end_index) to designate the subarray with the highest sum.

    Explanation: creating 2 lists(start and end). len(start) == len(end) --> list_sums(sum(start[index]...end[index]))
    --> max(list_sums).index == correct index in the the lists(start, end)

    >>> print(sub2([0, 10, 20, -647, 10, 4, 20]))
    (4, 6)

    :param numbers: List of integers
    :return: Tuple containing - start_index and end_index
    """
    sum_temp = 0
    start = [0]
    end = []
    for index, num in enumerate(numbers):
        sum_temp += num
        if sum_temp + num < sum_temp:
            end.append(index - 1)
            start.append(index + 1)
    end.append(index)
    list_sums = []
    for i_start, i_end in zip(start, end):
        list_sums.append(sum([number for number in numbers[i_start:i_end + 1]]))

    index_max = list_sums.index(max(list_sums))
    return start[index_max], end[index_max]


if __name__ == "__main__":
    print(f"Expected tuple: {sub2([0, 10, 20, -647, 10, 4, 20])}")
