from functools import lru_cache


@lru_cache  # Ex 1, part 3-creates caching for climb identical calls (Optimized for 'height' values up to 129)
def climb(height: int) -> int:
    """
    Given a ladder with N steps, on which one is allowed to climb using one of the following:

    A single step climb
    2 steps climb
    implement a recursive function in python, that receives N and returns the number of legal ways to climb this ladder.

    Climb(n) -> k

    >>> from ex1 import climb
    >>> print(climb(5))
    8

    :param height: Number of ladder steps.
    :return: Number of ladder climbing options.
    """
    if height > 8:  # Answer for Ex 1, part 2
        print(height)

    if height <= 0:
        return 0
    elif height == 1:
        return 1
    elif height == 2:
        return 2
    return climb(height - 1) + climb(height - 2)


if __name__ == '__main__':
    height = 5
    print(f'There are {climb(height)} climb otions to go to ladder {height=}')
