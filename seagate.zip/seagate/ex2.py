

def sub(numbers: list[int]) -> tuple[int, int]:
    """
    Given an list of integers of the size of N,
    you need to return (start_index, end_index) to designate the subarray with the highest sum.

    >>> print(sub([0, 10, 20, -647, 10, 4, 20]))
    (4, 6)

    :param numbers: List of integers
    :return: Tuple containing - start_index and end_index
    """
    max_so_far = 0
    current_max = 0
    start_index = 0
    end_index = 0
    j = 0

    for i in range(len(numbers)):
        current_max += numbers[i]

        if current_max > max_so_far:
            max_so_far = current_max
            start_index = j
            end_index = i

        if current_max < 0:
            current_max = 0
            j = i + 1
    return start_index, end_index


if __name__ == "__main__":
    print(f"Expected tuple: {sub([0, 10, 20, -647, 10, 4, 20])}")
